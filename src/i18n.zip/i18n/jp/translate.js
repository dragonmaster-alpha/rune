
{
    "translations": {
        "Max Supply": "トータル供給量",
        "The First NFT Hyperfarm": "初めてのNFTハイパーファーム",
        "Open App": "アプリを開く",
        "Starter Guide": "スターターガイド",
        "Purchase Runes": "ルーンを購入",
        "Blockchain Gaming": "ブロックチェーンゲーム",
        "Evolving NFTs": "進化するNFT",
        "You can start building your character right away. Choose from 1 of 7 classes, join a guild, and raid farms to start earning runes instantly.": "すぐにキャラクターを作成できます。 7つの職業から1つ選択したら、ギルドに参加し、農場を襲撃して、多くのルーンを獲得しましょう。",
        "Imagine a virtual world like Ready Player One, where your NFTs adapt to the game you're playing? We're building the market first, by distributing NFTs in Rune farms, that can later be used in Rune games.": "レディ・プレイヤー1のような仮想世界を想像してみてください。ここはNFTとゲームが融合した世界です。ルーンファームでNFTを配布し、それをルーンゲームで使用できるようにすることで、市場を構築しています。",
        "Craft": "クラフト",
        "Unique Crafted Items": "ユニークなクラフトアイテム",
        "NFT Hyperfarming": "NFTハイパーファーミング",
        "Buy Rune": "ルーンを購入",
        "Our Vision": "私たちの目標",
        "Patch Notes": "パッチノート",
        "Market Cap": "時価総額",
        "Price": "料金",
        "Holders": "開催人数",
        "Rune brings uniquely generated attributes to NFTs that have real utility.": "ルーンは、独自に生成され、実用性のある属性をNFTに付与します。",
        "Every item has an affect on your farm: increase yield, burn, chance to unlock hidden pool, and much more!": "これらのアイテムを使用することでファームを優位に運用できます：収穫量の増加、バーン、隠されたプールのロックを解除するチャンスです！",
        "Rune is the next evolution of DeFi farming. Farming is when you use your tokens to earn bonus tokens by staking them. Every week a new token is created (called a rune). It&apos;s farmed until the max supply of 50,000. That rune can then be combined with other runes to create NFTs. Those NFTs can be used to improve your earnings.": "Rune Farmは、暗号資産ゲームを代表するNFTプラットフォームを目指しています。Rune（ルーン）とルーンワードというNFTを組み合わせ、新たにNFTを獲得できるイールドファーミングを立ち上げました。プラットフォーム上のキャラクター＆ギルドは、その属性に応じてファームボーナス、またはNFT報酬を獲得するのに役立ちます。私たちは出資者や、プレセール、プレマイニングも行わず、公正に立ち上げられたプロジェクトです。",
        "Trade": "トレード"
    }
}