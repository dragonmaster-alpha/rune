export default {
    "translations": {
        "Max Supply": "Max Supply"
    }
}